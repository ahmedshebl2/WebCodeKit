import { redirect } from "next/navigation";

// أي مسار مش موجود يودّي المستخدم لصفحة 404.html الثابتة الموجودة في public/
export default function NotFound() {
  redirect("/404.html");
}
