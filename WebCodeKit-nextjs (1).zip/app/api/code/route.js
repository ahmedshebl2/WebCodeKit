import { NextResponse } from "next/server";
import { callAnthropic, sanitizeHistory, parseModelJson, CODE_SYSTEM_PROMPT } from "@/lib/anthropic";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

export const runtime = "nodejs";

export async function POST(req) {
  const ip = getClientIp(req);
  const { allowed, resetMs } = checkRateLimit(ip);
  if (!allowed) {
    return NextResponse.json(
      { error: "طلبات كثيرة جداً، حاول بعد لحظات." },
      { status: 429, headers: { "Retry-After": String(Math.ceil(resetMs / 1000)) } }
    );
  }

  try {
    const body = await req.json().catch(() => ({}));
    const { prompt, history } = body || {};

    if (!prompt || typeof prompt !== "string") {
      return NextResponse.json({ error: "prompt مطلوب." }, { status: 400 });
    }

    const messages = [...sanitizeHistory(history), { role: "user", content: prompt }];

    const text = await callAnthropic({
      system: CODE_SYSTEM_PROMPT,
      messages,
      max_tokens: 3000,
    });

    let parsed;
    try {
      parsed = parseModelJson(text);
    } catch {
      console.error("JSON parse error from model output:", text.slice(0, 300));
      return NextResponse.json({ error: "الموديل رجّع صيغة غير صالحة." }, { status: 502 });
    }

    return NextResponse.json(parsed);
  } catch (err) {
    console.error("Code error:", err.message);
    return NextResponse.json({ error: "حصل خطأ في توليد الكود." }, { status: 500 });
  }
}
