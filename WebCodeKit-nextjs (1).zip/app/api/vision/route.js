import { NextResponse } from "next/server";
import { callAnthropicVision, parseModelJson, VISION_SYSTEM_PROMPT } from "@/lib/anthropic";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

export const runtime = "nodejs";

export async function POST(req) {
  const ip = getClientIp(req);
  const { allowed, resetMs } = checkRateLimit(ip);
  if (!allowed) {
    return NextResponse.json(
      { error: "طلبات كثيرة جداً، حاول بعد لحظات." },
      { status: 429, headers: { "Retry-After": String(Math.ceil(resetMs / 1000)) } }
    );
  }

  try {
    const body = await req.json().catch(() => ({}));
    const { prompt, imageBase64, imageType } = body || {};

    if (!imageBase64 || !imageType) {
      return NextResponse.json({ error: "imageBase64 و imageType مطلوبين." }, { status: 400 });
    }

    const visionPrompt = prompt || "Analyze this UI design and generate matching HTML+CSS code.";

    const text = await callAnthropicVision({
      system: VISION_SYSTEM_PROMPT,
      prompt: visionPrompt,
      imageBase64,
      imageType,
      max_tokens: 4000,
    });

    let parsed;
    try {
      parsed = parseModelJson(text);
    } catch {
      console.error("Vision JSON parse error:", text.slice(0, 300));
      return NextResponse.json({ error: "الموديل رجّع صيغة غير صالحة." }, { status: 502 });
    }

    return NextResponse.json(parsed);
  } catch (err) {
    console.error("Vision error:", err.message);
    return NextResponse.json({ error: "حصل خطأ في تحليل الصورة." }, { status: 500 });
  }
}
