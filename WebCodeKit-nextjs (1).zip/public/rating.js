/* =====================================================
   WEBCODEKIT — rating.js  v2.0
   Star rating system for components.
   - Saves ratings in localStorage
   - Touch-friendly (no ghost hover on mobile)
   - Responsive tap targets
   ===================================================== */

(function () {
  const STORAGE_KEY = "wck_ratings";
  const isTouchDevice = () =>
    window.matchMedia("(pointer: coarse)").matches ||
    "ontouchstart" in window;

  /* ---------- Storage helpers ---------- */
  function getRatings() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; }
    catch { return {}; }
  }

  function saveRating(id, value) {
    const ratings = getRatings();
    ratings[id] = value;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ratings));
  }

  function getRating(id) {
    return getRatings()[id] || 0;
  }

  /* ---------- Build HTML ---------- */
  function buildStars(id, currentRating) {
    let html = `<div class="star-rating" data-id="${id}" role="group" aria-label="Rate this component">`;
    for (let i = 1; i <= 5; i++) {
      const filled = i <= currentRating;
      html += `<button
        class="star ${filled ? "active" : ""}"
        data-value="${i}"
        title="Rate ${i} star${i > 1 ? "s" : ""}"
        aria-label="${i} star${i > 1 ? "s" : ""}"
        aria-pressed="${filled}"
        type="button">
        <i class="fa${filled ? "s" : "r"} fa-star" aria-hidden="true"></i>
      </button>`;
    }
    html += `<span class="rating-count" aria-live="polite">${
      currentRating > 0 ? currentRating + "/5" : ""
    }</span>`;
    html += `</div>`;
    return html;
  }

  /* ---------- Apply saved state ---------- */
  function applySavedState(stars, saved) {
    stars.forEach((s, i) => {
      const on = i < saved;
      s.classList.toggle("active", on);
      s.classList.remove("hover");
      s.setAttribute("aria-pressed", on);
      s.querySelector("i").className = on ? "fas fa-star" : "far fa-star";
    });
  }

  /* ---------- Attach listeners ---------- */
  function attachRatingListeners(wrapper) {
    const stars = Array.from(wrapper.querySelectorAll(".star"));
    const id    = wrapper.getAttribute("data-id");
    const countEl = wrapper.querySelector(".rating-count");
    const touch = isTouchDevice();

    /* ---- Desktop: hover preview ---- */
    if (!touch) {
      stars.forEach((star) => {
        star.addEventListener("mouseenter", function () {
          const val = parseInt(this.dataset.value);
          stars.forEach((s, i) => {
            const on = i < val;
            s.querySelector("i").className = on ? "fas fa-star" : "far fa-star";
            s.classList.toggle("hover", on);
          });
        });
      });

      wrapper.addEventListener("mouseleave", () => {
        applySavedState(stars, getRating(id));
      });
    }

    /* ---- Click / Tap to rate ---- */
    stars.forEach((star) => {
      star.addEventListener("click", function (e) {
        e.stopPropagation();
        const val = parseInt(this.dataset.value);
        saveRating(id, val);

        // Visual update
        stars.forEach((s, i) => {
          const on = i < val;
          s.classList.toggle("active", on);
          s.classList.remove("hover");
          s.setAttribute("aria-pressed", on);
          s.querySelector("i").className = on ? "fas fa-star" : "far fa-star";
        });
        if (countEl) countEl.textContent = val + "/5";

        // Tap/click bounce animation
        this.style.transform = "scale(1.45)";
        setTimeout(() => { this.style.transform = ""; }, 280);
      });

      /* Touch: prevent ghost hover flash */
      if (touch) {
        star.addEventListener("touchstart", function () {
          // Brief highlight so user knows they touched
          this.classList.add("hover");
        }, { passive: true });

        star.addEventListener("touchend", function () {
          this.classList.remove("hover");
        }, { passive: true });
      }
    });
  }

  /* ---------- Init on DOM ready ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    const items = document.querySelectorAll(
      ".button-item, .card-item, .form-card, .system-card"
    );

    items.forEach((item) => {
      const favBtn = item.querySelector(".fav-btn");
      const id =
        favBtn?.getAttribute("data-fav") ||
        item.getAttribute("data-id") ||
        Math.random().toString(36).slice(2);
      const ratingId = "rating_" + id;
      const current  = getRating(ratingId);

      const tmp = document.createElement("div");
      tmp.innerHTML = buildStars(ratingId, current);
      const ratingWidget = tmp.querySelector(".star-rating");

      if (favBtn) {
        favBtn.insertAdjacentElement("afterend", ratingWidget);
      } else {
        item.insertAdjacentElement("afterbegin", ratingWidget);
      }

      attachRatingListeners(item.querySelector(".star-rating"));
    });
  });
})();
