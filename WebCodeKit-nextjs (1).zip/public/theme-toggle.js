/* ===== WebCodeKit — Theme Toggle ===== */
/* The sun/moon icon is now an inline SVG (#theme-icon) with two groups
   (.icon-sun / .icon-moon). Switching is handled purely via the
   [data-theme] attribute in CSS (navbar.css), so this script only needs
   to flip the attribute + persist the preference. */

function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute("data-theme") === "dark";
  const next = isDark ? "light" : "dark";

  html.setAttribute("data-theme", next);
  localStorage.setItem("theme", next);
}

// Apply saved theme immediately on load (before DOMContentLoaded to prevent flash)
(function () {
  const saved = localStorage.getItem("theme") || "dark";
  document.documentElement.setAttribute("data-theme", saved);
})();
