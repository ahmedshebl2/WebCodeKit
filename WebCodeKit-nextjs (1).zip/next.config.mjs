/** @type {import('next').NextConfig} */
const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "SAMEORIGIN" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
];

const nextConfig = {
  poweredByHeader: false, // بنشيل هيدر "X-Powered-By: Next.js" لأسباب أمنية
  compress: true, // gzip/brotli تلقائي على الاستجابات

  async rewrites() {
    return [
      // فتح الدومين الرئيسي (بدون /index.html) يودّي مباشرة لصفحة الهوم
      { source: "/", destination: "/index.html" },
    ];
  },

  async headers() {
    return [
      {
        // كل الصفحات والـ API: هيدرز أمان أساسية
        source: "/:path*",
        headers: securityHeaders,
      },
      {
        // ملفات ثابتة (صور/أيقونات) تتكاش لمدة سنة عند العميل والـ CDN
        source: "/icons/:path*",
        headers: [
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
        ],
      },
      {
        source: "/:file(favicon\\.ico|favicon\\.svg|og-preview\\.png)",
        headers: [
          { key: "Cache-Control", value: "public, max-age=86400" },
        ],
      },
      {
        // CSS/JS المضغوطة (.min) تتكاش لفترة أطول لأن اسمها بيتغير مع كل نسخة مهمة
        source: "/:path*.min.(css|js)",
        headers: [
          { key: "Cache-Control", value: "public, max-age=604800, must-revalidate" },
        ],
      },
      {
        // ال API نفسه ميتخزنش أبداً — كل رد لازم يبقى fresh
        source: "/api/:path*",
        headers: [{ key: "Cache-Control", value: "no-store" }],
      },
    ];
  },
};

export default nextConfig;
